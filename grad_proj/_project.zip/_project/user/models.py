from django.db import models
from django.utils import timezone
from django.db.models import Sum ,F, DecimalField , ForeignKey
from decimal import Decimal
from django.contrib.auth.models import User

# ===============================================================================================
